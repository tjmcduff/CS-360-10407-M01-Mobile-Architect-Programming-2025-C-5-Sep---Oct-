package com.example.taylormcduffiesapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Start disabled
        buttonSayHello.setEnabled(false);

        // Enable/disable button dynamically based on text presence
        nameText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                boolean hasText = s != null && s.toString().trim().length() > 0;
                buttonSayHello.setEnabled(hasText);
            }
        });
    }

    // accepts View
    public void SayHello(View view) {
        if (nameText == null) return; // defensive
        String name = nameText.getText() != null ? nameText.getText().toString().trim() : "";
        if (name.isEmpty()) return;   // if empty, just return per rubric
        if (textGreeting != null) {
            textGreeting.setText("Hello " + name);
        }
    }
}
