package com.example.taylormcduffiesapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserDao {
    private final DatabaseHelper dbHelper;

    public UserDao(Context ctx) { this.dbHelper = new DatabaseHelper(ctx); }

    // Create new user (returns true if created, false if username exists)
    public boolean createUser(String username, String password) {
        if (userExists(username)) return false;
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.U_USERNAME, username.trim());
        cv.put(DatabaseHelper.U_PASSWORD, password); // NOTE: demo only; real apps should hash
        long id = db.insert(DatabaseHelper.T_USERS, null, cv);
        db.close();
        return id != -1;
    }

    // Check if username already exists
    public boolean userExists(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_USERS,
                new String[]{DatabaseHelper.U_ID},
                DatabaseHelper.U_USERNAME + "=?",
                new String[]{username.trim()}, null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        db.close();
        return exists;
    }

    // Authenticate user (true if username/password match)
    public boolean authenticate(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_USERS,
                new String[]{DatabaseHelper.U_ID},
                DatabaseHelper.U_USERNAME + "=? AND " + DatabaseHelper.U_PASSWORD + "=?",
                new String[]{username.trim(), password}, null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        db.close();
        return ok;
    }

    // Get user id (for linking weight rows)
    public long getUserId(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.query(DatabaseHelper.T_USERS,
                new String[]{DatabaseHelper.U_ID},
                DatabaseHelper.U_USERNAME + "=?",
                new String[]{username.trim()}, null, null, null);
        long id = -1;
        if (c.moveToFirst()) id = c.getLong(0);
        c.close();
        db.close();
        return id;
    }
}
