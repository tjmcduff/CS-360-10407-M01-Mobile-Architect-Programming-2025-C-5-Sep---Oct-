package com.example.taylormcduffiesapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "weight_tracker.db";
    public static final int DB_VERSION = 2;

    // Table: users
    public static final String T_USERS = "users";
    public static final String U_ID = "_id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // Table: weights
    public static final String T_WEIGHTS = "weights";
    public static final String W_ID = "_id";
    public static final String W_USER_ID = "user_id";
    public static final String W_DATE = "entry_date";   // ISO-8601 string, e.g., 2025-10-18
    public static final String W_WEIGHT = "weight";     // stored as REAL
    public static final String W_NOTES = "notes";

    private static final String CREATE_USERS =
            "CREATE TABLE " + T_USERS + " (" +
                    U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    U_USERNAME + " TEXT UNIQUE NOT NULL, " +
                    U_PASSWORD + " TEXT NOT NULL" +
                    ");";

    private static final String CREATE_WEIGHTS =
            "CREATE TABLE " + T_WEIGHTS + " (" +
                    W_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    W_USER_ID + " INTEGER NOT NULL, " +
                    W_DATE + " TEXT NOT NULL, " +
                    W_WEIGHT + " REAL NOT NULL, " +
                    W_NOTES + " TEXT, " +
                    "FOREIGN KEY(" + W_USER_ID + ") REFERENCES " + T_USERS + "(" + U_ID + ")" +
                    ");";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USERS);
        db.execSQL(CREATE_WEIGHTS);
        // Optional seed: create a demo user for quick testing
        // db.execSQL("INSERT INTO " + T_USERS + " (" + U_USERNAME + "," + U_PASSWORD + ") VALUES('demo','demo123');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }
}
