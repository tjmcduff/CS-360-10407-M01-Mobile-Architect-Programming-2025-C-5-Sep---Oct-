package com.example.taylormcduffiesapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class WeightDao {
    private final DatabaseHelper dbHelper;

    public WeightDao(Context ctx) {
        this.dbHelper = new DatabaseHelper(ctx);
    }

    // CREATE
    public long addEntry(long userId, String date, double weight, String notes) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.W_USER_ID, userId);
        cv.put(DatabaseHelper.W_DATE, date.trim());
        cv.put(DatabaseHelper.W_WEIGHT, weight);
        cv.put(DatabaseHelper.W_NOTES, notes == null ? "" : notes.trim());
        long id = db.insert(DatabaseHelper.T_WEIGHTS, null, cv);
        db.close();
        return id; // returns -1 on failure
    }

    // READ (all for one user)
    public List<WeightEntry> getAllForUser(long userId) {
        List<WeightEntry> list = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor c = db.query(
                DatabaseHelper.T_WEIGHTS,
                new String[]{ DatabaseHelper.W_ID, DatabaseHelper.W_USER_ID, DatabaseHelper.W_DATE, DatabaseHelper.W_WEIGHT, DatabaseHelper.W_NOTES },
                DatabaseHelper.W_USER_ID + "=?",
                new String[]{ String.valueOf(userId) },
                null, null,
                DatabaseHelper.W_DATE + " DESC" // newest first
        );

        while (c.moveToNext()) {
            long id = c.getLong(0);
            long uid = c.getLong(1);
            String date = c.getString(2);
            double wt = c.getDouble(3);
            String notes = c.getString(4);
            list.add(new WeightEntry(id, uid, date, wt, notes));
        }
        c.close();
        db.close();
        return list;
    }

    // UPDATE (by row id)
    public boolean updateEntry(long id, String date, double weight, String notes) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.W_DATE, date.trim());
        cv.put(DatabaseHelper.W_WEIGHT, weight);
        cv.put(DatabaseHelper.W_NOTES, notes == null ? "" : notes.trim());
        int rows = db.update(DatabaseHelper.T_WEIGHTS, cv, DatabaseHelper.W_ID + "=?", new String[]{ String.valueOf(id) });
        db.close();
        return rows > 0;
    }

    // DELETE (by row id)
    public boolean deleteEntry(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rows = db.delete(DatabaseHelper.T_WEIGHTS, DatabaseHelper.W_ID + "=?", new String[]{ String.valueOf(id) });
        db.close();
        return rows > 0;
    }
}
