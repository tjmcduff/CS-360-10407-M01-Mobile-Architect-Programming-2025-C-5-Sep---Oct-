package com.example.taylormcduffiesapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class DataActivity extends AppCompatActivity {

    private long userId = -1L;
    private WeightDao weightDao;

    private EditText etDate, etWeight, etNotes;
    private TableLayout tableEntries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // keep your edge-to-edge behavior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets sys = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom);
            return insets;
        });

        weightDao = new WeightDao(this);

        // Grab user info from LoginActivity
        userId = getIntent().getLongExtra("USER_ID", -1L);
        String username = getIntent().getStringExtra("USERNAME");

        // Bind views
        etDate = findViewById(R.id.etDate);
        etWeight = findViewById(R.id.etWeight);
        etNotes = findViewById(R.id.etNotes);
        tableEntries = findViewById(R.id.tableEntries);
        Button btnAdd = findViewById(R.id.btnAddEntry);
        Button btnBack = findViewById(R.id.btnBackToLogin);

        // Add entry
        btnAdd.setOnClickListener(v -> onAdd());

        // Back (optional for now)
        btnBack.setOnClickListener(v -> finish());

        // Load table
        refreshTable();
    }

    private void onAdd() {
        String date = etDate.getText().toString().trim();      // yyyy-MM-dd
        String weightStr = etWeight.getText().toString().trim();
        String notes = etNotes.getText().toString().trim();

        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weightStr)) {
            toast("Enter date and weight");
            return;
        }
        double weight;
        try {
            weight = Double.parseDouble(weightStr);
        } catch (NumberFormatException e) {
            toast("Weight must be a number");
            return;
        }

        long id = weightDao.addEntry(userId, date, weight, notes);
        if (id == -1) {
            toast("Failed to add entry");
        } else {
            toast("Entry added");
            etNotes.setText("");
            // Keep the date/weight to speed data entry, or clear them if you want:
            // etDate.setText(""); etWeight.setText("");
            refreshTable();
        }
    }

    private void refreshTable() {
        // Keep header (index 0), remove the rest
        while (tableEntries.getChildCount() > 1) {
            tableEntries.removeViewAt(1);
        }

        List<WeightEntry> list = weightDao.getAllForUser(userId);
        for (WeightEntry e : list) {
            TableRow row = new TableRow(this);
            row.setPadding(dp(0), dp(6), dp(0), dp(6));

            TextView tvDate = new TextView(this);
            tvDate.setText(e.getDate());
            tvDate.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvWeight = new TextView(this);
            tvWeight.setText(String.valueOf(e.getWeight()));
            tvWeight.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

            Button btnDelete = new Button(this);
            btnDelete.setText(getString(R.string.btn_delete));
            btnDelete.setOnClickListener(v -> {
                boolean ok = weightDao.deleteEntry(e.getId());
                if (ok) {
                    toast("Deleted");
                    refreshTable();
                } else {
                    toast("Delete failed");
                }
            });
            btnDelete.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));

            row.addView(tvDate);
            row.addView(tvWeight);
            row.addView(btnDelete);

            tableEntries.addView(row);
        }
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
