package com.example.taylormcduffiesapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsActivity extends AppCompatActivity {

    private TextView tvPermissionStatusValue;
    private Button btnRequestPermission, btnSendTest, btnBackToData;

    // Register a permission launcher
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    toast("Permission granted!");
                    btnSendTest.setEnabled(true);
                } else {
                    toast("Permission denied.");
                    btnSendTest.setEnabled(false);
                }
                updateStatus();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // Keep your edge-to-edge behavior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets sys = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom);
            return insets;
        });

        tvPermissionStatusValue = findViewById(R.id.tvPermissionStatusValue);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSendTest = findViewById(R.id.btnSendTest);
        btnBackToData = findViewById(R.id.btnBackToData);

        btnRequestPermission.setOnClickListener(v ->
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS));

        btnSendTest.setOnClickListener(v -> sendTestSms());

        btnBackToData.setOnClickListener(v -> finish());

        updateStatus();
    }

    private void updateStatus() {
        boolean granted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        tvPermissionStatusValue.setText(granted ? "Permission granted" : "Permission denied");
        btnSendTest.setEnabled(granted);
    }

    private void sendTestSms() {
        boolean granted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        if (!granted) {
            toast("Cannot send SMS: permission denied.");
            return;
        }
        try {
            SmsManager sms = SmsManager.getDefault();
            // 5554 is the emulator’s “phone number”
            sms.sendTextMessage("5554", null,
                    "Test message from Weight Tracker (SMS feature demo)",
                    null, null);
            toast("Test SMS sent! Check the emulator’s SMS inbox.");
        } catch (Exception e) {
            toast("Failed to send: " + e.getMessage());
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
