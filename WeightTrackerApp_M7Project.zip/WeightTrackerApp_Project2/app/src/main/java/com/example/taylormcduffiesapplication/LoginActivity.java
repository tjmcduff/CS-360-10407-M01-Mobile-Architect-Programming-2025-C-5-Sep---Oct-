package com.example.taylormcduffiesapplication;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Keep your edge-to-edge padding behavior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userDao = new UserDao(this);

        EditText etUser = findViewById(R.id.etUsername);
        EditText etPass = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreateAccount); // matches your XML id

        btnCreate.setOnClickListener(v -> {
            String u = etUser.getText().toString();
            String p = etPass.getText().toString();
            if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
                toast("Enter username & password");
                return;
            }
            boolean ok = userDao.createUser(u, p);
            toast(ok ? "Account created! You can log in now." : "Username already exists.");
        });

        btnLogin.setOnClickListener(v -> {
            String u = etUser.getText().toString();
            String p = etPass.getText().toString();
            if (TextUtils.isEmpty(u) || TextUtils.isEmpty(p)) {
                toast("Enter username & password");
                return;
            }
            if (userDao.authenticate(u, p)) {
                long userId = userDao.getUserId(u);
                Intent i = new Intent(this, DataActivity.class);
                i.putExtra("USER_ID", userId);
                i.putExtra("USERNAME", u);
                startActivity(i);
                finish();
            } else {
                toast("Invalid credentials");
            }
        });
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
